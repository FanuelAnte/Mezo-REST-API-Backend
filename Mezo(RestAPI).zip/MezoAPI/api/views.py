from rest_framework.views import APIView
from rest_framework.response import Response
from shop import models
from .serializers import *
from django.contrib.auth import authenticate

class LoginView(APIView):
    permission_classes = ()
    def post(self, request,):
        username = request.data.get("username")
        password = request.data.get("password")
        user = authenticate(username=username, password=password)
        if user:
            return Response({"token": user.auth_token.key})
        else:
            return Response({"error": "Wrong Credentials"})

class ProductsView(APIView):
    def get(self, request):
        products = models.Product.objects.filter(ApprovalStatus = 'Approved')
        data = ProductSerializer(products, many=True).data
        return Response(data)

class ProductDetailsView(APIView):
    def get(self, request, ProductId):
        product = models.Product.objects.get(ProductID__exact = ProductId)
        data = ProductSerializer(product).data
        return Response(data)

class AddToCartView(APIView):
    def get(self, request, ProductId):
        RetailerUser = request.user.id
        product = models.Product.objects.get(ProductID = ProductId)
        person, created = models.Cart.objects.get_or_create(CartUser = RetailerUser)
        person.CartItems.add(product)
        cart = models.Cart.objects.get(CartUser = RetailerUser)
        data = CartSerializer(cart).data
        return Response(data)

class DeleteFromCartView(APIView):
    def get(self, request, ProductId):
        RetailerUser = request.user.id
        product = models.Product.objects.get(ProductID = ProductId)
        person, created = models.Cart.objects.get_or_create(CartUser = RetailerUser)
        person.CartItems.remove(product)
        cart = models.Cart.objects.get(CartUser = RetailerUser)
        data = CartSerializer(cart).data
        return Response(data)

class ProductSeachView(APIView):
    def get(self, request, ProductName):
        Searchproducts = models.Product.objects.filter(ProductName__contains = ProductName).filter(ApprovalStatus__exact = 'Approved')
        data = ProductSerializer(Searchproducts, many=True).data
        return Response(data)

class WholesalersView(APIView):
    def get(self, request):
        Wholesalers = models.Supplier.objects.all()
        data = SupplierSerializer(Wholesalers, many=True).data
        return Response(data)

class ImportersView(APIView):
    def get(self, request):
        Wholesalers = models.Supplier.objects.filter(SupplierType__exact = 'Importer')
        data = SupplierSerializer(Wholesalers, many=True).data
        return Response(data)

class WholesalerProuctsView(APIView):
    def get(self, request, WholesalerID):
        Wholesaler = models.Supplier.objects.get(SuppierID = WholesalerID)
        products = models.Product.objects.filter(Supplier__exact = Wholesaler).filter(ApprovalStatus = 'Approved')
        data = ProductSerializer(products, many=True).data
        return Response(data)

class ImporterProuctsView(APIView):
    def get(self, request, ImporterID):
        Importer = models.Supplier.objects.get(SuppierID = ImporterID)
        products = models.Product.objects.filter(Supplier__exact = Importer).filter(ApprovalStatus = 'Approved')
        data = ProductSerializer(products, many=True).data
        return Response(data)

class MyProductsView(APIView):
    def get(self, request):
        SupplierUser = request.user.id
        products = models.Product.objects.filter(Supplier = SupplierUser)
        data = ProductSerializer(products, many=True).data
        return Response(data)

class MyCartView(APIView):
    def get(self, request):
        RetailerUser = request.user.id
        cart = models.Cart.objects.get(CartUser = RetailerUser)
        data = CartSerializer(cart).data
        return Response(data)

class MyOrdersView(APIView):
    def get(self, request):
        SupplierUser = request.user.id
        orders = models.Transaction.objects.filter(Supplier = 1)
        data = TransactionSerializer(orders, many=True).data
        return Response(data)

class OrderProductView(APIView):
    serializer_class = TransactionSerializer
    def post(self, request, ProductId):
        product = models.Product.objects.get(ProductID = ProductId)
        supplier = product.Supplier
        RetailerUserId = request.user.id
        RetailerUserName = models.User.objects.get(id = RetailerUserId)
        RetailerUser = models.Retailer.objects.get(RetailerUser = RetailerUserName)
        amount =  int(request.data.get("ProductAmount"))
        total_price = int(amount) * int(product.Price)
        transaction = models.Transaction(Supplier = supplier, Retailer = RetailerUser, Product = product, ProductAmount = amount, TotalPrice = total_price)
        person, created = models.Cart.objects.get_or_create(CartUser = RetailerUserId)
        person.CartItems.remove(product)
        transaction.save()
        data = TransactionSerializer(transaction).data
        return Response(data)

class AddProductView(APIView):
    def post(self, request):
        SupplierUser = request.user.id
        ProductName = request.data.get("ProductName")
        Description = request.data.get("Description")
        Price = request.data.get("Price")
        ProductCategory = request.data.get("ProductCategory")
        ProductImage = request.data.get("ProductImage")
        Amount = request.data.get("Amount")
        NewProduct = models.Product(ProductName = ProductName, Description = Description, Price = Price, ProductCategory = ProductCategory, ProductImage = ProductImage, Supplier = SupplierUser, Amount = Amount)
        NewProduct.save()
        data = ProductSerializer(NewProduct).data
        return Response(data)
