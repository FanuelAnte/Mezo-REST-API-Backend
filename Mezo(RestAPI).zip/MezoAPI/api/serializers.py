from rest_framework import serializers
from shop import models

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Product
        fields = ('ProductID','ProductName', 'Description', 'Price', 'ProductCategory', 'ProductImage', 'Amount')

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Categorie
        fields = '__all__'

class SupplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Supplier
        fields = '__all__'

class RetailerSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Retailer
        fields = '__all__'

class CartSerializer(serializers.ModelSerializer):
    CartItems = ProductSerializer(many=True)
    class Meta:
        model = models.Cart
        fields = ('CartID','CartUser','CartItems')

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Transaction
        fields = '__all__'
