from django.urls import path
from . import views

urlpatterns = [
    path("login/", views.LoginView.as_view(), name="login"),
    path('products/', views.ProductsView.as_view(), name='Products'),
    path('productDetails/<int:ProductId>/', views.ProductDetailsView.as_view(), name='productDetails'),
    path('SearchProduct/<str:ProductName>/', views.ProductSeachView.as_view(), name='SearchProduct'),
    path('Wholesalers/', views.WholesalersView.as_view(), name='Wholesalers'),
    path('Importers/', views.ImportersView.as_view(), name='Importers'),
    path('WholesalerProducts/<int:WholesalerID>/', views.WholesalerProuctsView.as_view(), name='WholesalerProducts'),
    path('ImporterProducts/<int:ImporterID>/', views.ImporterProuctsView.as_view(), name='ImporterProducts'),
    path('MyProducts/', views.MyProductsView.as_view(), name='MyProducts'),
    path('MyCart/', views.MyCartView.as_view(), name='MyCart'),
    path('MyOrders/', views.MyOrdersView.as_view(), name='MyOrders'),
    path('AddToCart/<int:ProductId>/', views.AddToCartView.as_view(), name='AddToCart'),
    path('DeleteFromCart/<int:ProductId>/', views.DeleteFromCartView.as_view(), name='DeleteFromCart'),
    path('OrderProduct/<int:ProductId>/', views.OrderProductView.as_view(), name='OrderProduct'),
    path('AddProduct/', views.AddProductView.as_view(), name='AddProduct'),
]
