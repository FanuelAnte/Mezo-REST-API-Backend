from django.contrib import admin

from .models import *

class ProductAdmin(admin.ModelAdmin):
    list_display = ('ProductName', 'ApprovalStatus', 'PremiumStatus','ProperPrice', 'ProperDate', 'Amount')
    list_filter = ['DateAdded','ApprovalStatus', 'PremiumStatus', 'ProductCategory']
    list_editable = ['ApprovalStatus', 'PremiumStatus']
    fieldsets = [
        ('Approval Status', {'fields': ['ApprovalStatus', 'PremiumStatus']}),
        ('Product information', {'fields': ['ProductName', 'Price', 'Amount','ProductCategory', 'Supplier','Description', 'ProductImage']}),
    ]

class TransactionAdmin(admin.ModelAdmin):
    list_display = ('Retailer', 'Supplier', 'Product', 'Date', 'ProductAmount', 'Delivered', 'TotalPrice')
    list_filter = ['Date', 'Retailer', 'Delivered']
    list_editable = ['Delivered']

admin.site.register(Cart)
admin.site.register(Supplier)
admin.site.register(Product, ProductAdmin)
admin.site.register(Retailer)
admin.site.register(Transaction, TransactionAdmin)
admin.site.register(Categorie)
