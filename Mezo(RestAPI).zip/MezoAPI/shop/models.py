from django.db import models
from django.contrib.auth.models import User
import datetime

class Supplier(models.Model):
    Supplier_Type_Choices = (
    ('Wholesaler','Wholesaler'),
    ('Importer','Importer'),
    )
    SuppierID = models.AutoField(primary_key = True)
    SupplierName = models.CharField(max_length = 100)
    SupplierUser = models.ForeignKey(User, on_delete = models.SET_NULL, null = True, related_name = 'SupplierUser')
    SupplierLogo = models.ImageField(upload_to = 'SupplierLogos/')
    SupplierType = models.CharField(max_length = 100, choices = Supplier_Type_Choices, default = 'Wholesaler')

    def __str__(self):
        return self.SupplierName

class Categorie(models.Model):
    CategoryID = models.AutoField(primary_key = True)
    CategoryName = models.CharField(max_length = 100)
    CategoryDescription = models.TextField()

    def __str__(self):
        return self.CategoryName

class Product(models.Model):
    Approval_status_choices = (
    ('Approved','Approved'),
    ('Not Approved','Not Approved'),
    )
    Premium_status_choices = (
    ('Premium','Premium'),
    ('Not Premium','Not Premium'),
    )
    ProductID = models.AutoField(primary_key = True)
    ProductName = models.CharField(max_length = 100)
    Description =  models.TextField()
    Price = models.IntegerField(default = 0)
    ProductCategory = models.ForeignKey(Categorie, on_delete = models.SET_NULL, null = True)
    ProductImage = models.ImageField(upload_to = 'ProductImages/')
    Supplier = models.ForeignKey(Supplier, on_delete = models.SET_NULL, null = True)
    Amount = models.PositiveIntegerField(default = 1)
    DateAdded = models.DateTimeField(auto_now_add = True)
    DateEdited = models.DateTimeField(auto_now = True)
    ApprovalStatus = models.CharField(max_length = 100, choices = Approval_status_choices, default = 'Not Approved')
    PremiumStatus = models.CharField(max_length = 100, choices = Premium_status_choices, default = 'Not Premium')

    def __str__(self):
        return self.ProductName

    def ProperPrice(self):
        return 'ETB' + ' ' + str(self.Price)

    def ShortName(self):
        return self.ProductName[:13]

    def Summary(self):
        return self.Description[:40] + '...'

    def ProperDate(self):
        return self.DateAdded.strftime('%b %e, %y')

class Cart(models.Model):
    CartID = models.AutoField(primary_key = True)
    CartUser = models.OneToOneField(User, on_delete = models.SET_NULL, null = True, related_name = 'CartUser')
    CartItems = models.ManyToManyField(Product)

class Retailer(models.Model):
    RetailerID = models.AutoField(primary_key = True)
    RetailerName = models.CharField(max_length = 100)
    RetailerUser = models.ForeignKey(User, on_delete = models.SET_NULL, null = True, related_name = 'RetailerUser')
    RetailerLogo = models.ImageField(upload_to = 'RetailerLogos/')
    RetailerNumber = models.CharField(max_length= 255, default = 0)

    def __str__(self):
        return self.RetailerName

class Transaction(models.Model):
    DelChoices=(
    ('Delivered','Delivered'),
    ('Not Delivered','Not Delivered'),
    )
    TransactionID = models.AutoField(primary_key = True)
    Supplier = models.ForeignKey(Supplier, on_delete = models.SET_NULL, null = True)
    Retailer = models.ForeignKey(Retailer, on_delete = models.SET_NULL, null = True)
    Product = models.ForeignKey(Product, on_delete = models.SET_NULL, null = True)
    Date = models.DateTimeField(auto_now_add = True)
    ProductAmount = models.PositiveIntegerField(default = 1)
    Delivered = models.CharField(max_length = 100, choices=DelChoices, default='Not Delivered')
    TotalPrice = models.PositiveIntegerField(default = 1)

    def __str__(self):
        return str(self.Retailer)

    def ProperTotalPrice(self):
        return 'ETB' + ' ' + str(self.TotalPrice)
